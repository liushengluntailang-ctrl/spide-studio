# spide-studio
Ultra-fast, Webview-free native desktop client for the spide AI ecosystem (spide Speed &amp; spide Null). Built with C++20 and Qt 6. Eliminates Electron overhead for sub-second startup and direct GPU rendering. Features zero-chattiness streaming, direct file injection, and real-time sync with aistudio.spide.dev.

# SPIDE Studio v0.1

SPIDE Studio is a lightweight, native Qt Widgets IDE for the SPIDE AI ecosystem.
It combines a project explorer, multi-tab code editor, integrated terminal, and
SPIDE AI chat panel in a single C++20 application.

## Features

- Open a project folder and browse, create, rename, and delete files/folders.
- Multi-file editor with tabs, line numbers, basic syntax highlighting, save,
	Save As, `Ctrl+S`, `Ctrl+O`, and unsaved-change indicators.
- Project-aware terminal with stdout/stderr output and configurable shell.
- Gemini provider behind the `IAIProvider` interface. The current file or
	selected code can be included in chat context.
- Settings for Gemini API key, provider, model, editor font size, theme, and
	terminal shell. The API key is stored in Qt's local application settings and
	is never part of the source code.

## Requirements

- CMake 3.21 or newer
- A C++20 compiler
- Qt 6 with the `Widgets` and `Network` modules (`qt6-base-dev` on Ubuntu)

## Build

```sh
cmake -S . -B build
cmake --build build
./build/spide-studio
```

On Ubuntu/Debian, install the Qt dependency with:

```sh
sudo apt install qt6-base-dev
```

The Gemini API key is configured from `View > Settings...`. Without a key,
the rest of the IDE remains fully usable and the AI panel reports a clear
configuration error.
