#pragma once

#include <QDialog>

class QComboBox;
class QLineEdit;
class QSpinBox;

class Settings : public QDialog
{
    Q_OBJECT
public:
    explicit Settings(QWidget *parent = nullptr);
    QString apiKey() const;
    QString provider() const;
    QString model() const;
signals:
    void settingsChanged();
private slots:
    void save();
private:
    QLineEdit *apiKeyEdit;
    QComboBox *providerCombo;
    QComboBox *modelCombo;
    QSpinBox *fontSizeSpin;
    QComboBox *themeCombo;
    QLineEdit *shellEdit;
};