#include "Settings.h"

#include <QComboBox>
#include <QFormLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QSettings>
#include <QSpinBox>
#include <QVBoxLayout>

Settings::Settings(QWidget *parent) : QDialog(parent), apiKeyEdit(new QLineEdit), providerCombo(new QComboBox), modelCombo(new QComboBox), fontSizeSpin(new QSpinBox), themeCombo(new QComboBox), shellEdit(new QLineEdit)
{
    setWindowTitle("SPIDE Studio Settings"); setModal(true); resize(420, 280);
    providerCombo->addItem("Gemini"); modelCombo->addItems({"gemini-3.8-flash", "gemini-3.1-pro-preview"});
    fontSizeSpin->setRange(8, 32); themeCombo->addItems({"Dark", "Light"}); shellEdit->setPlaceholderText("/bin/bash"); apiKeyEdit->setEchoMode(QLineEdit::Password);
    QSettings settings; apiKeyEdit->setText(settings.value("ai/apiKey").toString()); providerCombo->setCurrentText(settings.value("ai/provider", "Gemini").toString()); modelCombo->setCurrentText(settings.value("ai/model", "gemini-3.1-pro-preview").toString()); fontSizeSpin->setValue(settings.value("editor/fontSize", 12).toInt()); themeCombo->setCurrentText(settings.value("ui/theme", "Dark").toString()); shellEdit->setText(settings.value("terminal/shell").toString());
    auto *form = new QFormLayout; form->addRow("Gemini API Key", apiKeyEdit); form->addRow("AI Provider", providerCombo); form->addRow("AI Model", modelCombo); form->addRow("Font Size", fontSizeSpin); form->addRow("Theme", themeCombo); form->addRow("Terminal Shell", shellEdit);
    auto *saveButton = new QPushButton("Save"); auto *layout = new QVBoxLayout(this); layout->addLayout(form); layout->addWidget(saveButton); connect(saveButton, &QPushButton::clicked, this, &Settings::save);
}
QString Settings::apiKey() const { return apiKeyEdit->text(); }
QString Settings::provider() const { return providerCombo->currentText(); }
QString Settings::model() const { return modelCombo->currentText(); }
void Settings::save()
{
    QSettings settings; settings.setValue("ai/apiKey", apiKey()); settings.setValue("ai/provider", provider()); settings.setValue("ai/model", model()); settings.setValue("editor/fontSize", fontSizeSpin->value()); settings.setValue("ui/theme", themeCombo->currentText()); settings.setValue("terminal/shell", shellEdit->text()); emit settingsChanged(); accept();
}